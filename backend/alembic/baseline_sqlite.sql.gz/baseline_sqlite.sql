-- table: actor_object_attributions (table=actor_object_attributions)
CREATE TABLE actor_object_attributions (
            object_type TEXT NOT NULL,
            object_id TEXT NOT NULL,
            household_id TEXT NOT NULL,
            actor_user_id TEXT NOT NULL,
            attribution_source TEXT NOT NULL DEFAULT 'runtime_session',
            first_attributed_at TEXT NOT NULL,
            last_attributed_at TEXT NOT NULL,
            PRIMARY KEY (object_type, object_id)
        );

-- table: app_users (table=app_users)
CREATE TABLE app_users (
                    id TEXT PRIMARY KEY,
                    email TEXT NOT NULL UNIQUE,
                    password TEXT NOT NULL,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                , account_status TEXT NOT NULL DEFAULT 'active', password_hash TEXT, suspended_at TIMESTAMP NULL);

-- table: article_groups (table=article_groups)
CREATE TABLE article_groups (
    id TEXT PRIMARY KEY,
    household_id TEXT NOT NULL,
    name TEXT NOT NULL,
    normalized_name TEXT NOT NULL,
    status TEXT DEFAULT 'active',
    sort_order INTEGER DEFAULT 0,
    created_at TEXT,
    updated_at TEXT
);

-- table: auth_audit_log (table=auth_audit_log)
CREATE TABLE auth_audit_log (
            id TEXT PRIMARY KEY,
            actor_user_id TEXT NOT NULL,
            actor_type TEXT NOT NULL,
            household_id TEXT,
            support_session_id TEXT,
            action TEXT NOT NULL,
            object_type TEXT,
            object_id TEXT,
            old_value TEXT,
            new_value TEXT,
            reason TEXT,
            ticket_reference TEXT,
            created_at TEXT NOT NULL
        );

-- table: auth_membership_permission_overrides (table=auth_membership_permission_overrides)
CREATE TABLE auth_membership_permission_overrides (
            household_id TEXT NOT NULL,
            membership_id TEXT NOT NULL,
            permission_key TEXT NOT NULL,
            effect TEXT NOT NULL CHECK (effect IN ('allow', 'deny')),
            reason TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (household_id, membership_id, permission_key)
        );

-- table: auth_membership_roles (table=auth_membership_roles)
CREATE TABLE auth_membership_roles (
            household_id TEXT NOT NULL,
            membership_id TEXT NOT NULL,
            role_key TEXT NOT NULL,
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (household_id, membership_id)
        );

-- table: auth_permissions (table=auth_permissions)
CREATE TABLE auth_permissions (
            permission_key TEXT PRIMARY KEY,
            scope TEXT NOT NULL CHECK (scope IN ('household', 'platform')),
            description TEXT,
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

-- table: auth_platform_user_roles (table=auth_platform_user_roles)
CREATE TABLE auth_platform_user_roles (
            user_id TEXT NOT NULL,
            role_key TEXT NOT NULL,
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (user_id, role_key)
        );

-- table: auth_role_permissions (table=auth_role_permissions)
CREATE TABLE auth_role_permissions (
            role_key TEXT NOT NULL,
            permission_key TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (role_key, permission_key)
        );

-- table: auth_roles (table=auth_roles)
CREATE TABLE auth_roles (
            role_key TEXT PRIMARY KEY,
            scope TEXT NOT NULL CHECK (scope IN ('household', 'platform')),
            name TEXT NOT NULL,
            system_role INTEGER NOT NULL DEFAULT 1,
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

-- table: auth_support_sessions (table=auth_support_sessions)
CREATE TABLE auth_support_sessions (
            id TEXT PRIMARY KEY,
            support_user_id TEXT NOT NULL,
            household_id TEXT NOT NULL,
            access_level TEXT NOT NULL CHECK (access_level IN ('metadata', 'read', 'mutate', 'emergency')),
            reason TEXT NOT NULL,
            ticket_reference TEXT NOT NULL,
            starts_at TEXT NOT NULL,
            expires_at TEXT NOT NULL,
            revoked_at TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

-- table: external_article_product_links (table=external_article_product_links)
CREATE TABLE external_article_product_links (
                id TEXT PRIMARY KEY,
                retailer_code TEXT NOT NULL,
                receipt_text_normalized TEXT NOT NULL DEFAULT '',
                external_article_code TEXT NOT NULL DEFAULT '',
                global_product_id TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'confirmed',
                confirmed_by TEXT NULL,
                confirmed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                source_candidate_id TEXT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                CHECK (status IN ('confirmed', 'inactive')),
                CHECK (
                    length(trim(receipt_text_normalized)) > 0
                    OR length(trim(external_article_code)) > 0
                ),
                FOREIGN KEY (global_product_id)
                    REFERENCES global_products(id)
                    ON DELETE RESTRICT
            );

-- table: external_product_candidates (table=external_product_candidates)
CREATE TABLE external_product_candidates (
                id TEXT PRIMARY KEY,
                purchase_import_line_id TEXT NOT NULL,
                global_product_id TEXT,
                source_name TEXT NOT NULL,
                source_product_code TEXT,
                candidate_name TEXT,
                candidate_brand TEXT,
                candidate_category TEXT,
                candidate_image_url TEXT,
                candidate_source_url TEXT,
                candidate_stores TEXT,
                candidate_countries TEXT,
                score NUMERIC,
                match_reason TEXT,
                status TEXT NOT NULL DEFAULT 'candidate',
                raw_payload TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT
            );

-- table: frontteam_personal_households (table=frontteam_personal_households)
CREATE TABLE frontteam_personal_households (
            user_id TEXT PRIMARY KEY,
            household_id TEXT NOT NULL UNIQUE,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

-- table: global_products (table=global_products)
CREATE TABLE global_products (
                id TEXT PRIMARY KEY,
                primary_gtin TEXT,
                name TEXT NOT NULL,
                brand TEXT,
                variant TEXT,
                category TEXT,
                size_value NUMERIC,
                size_unit TEXT,
                product_fingerprint TEXT,
                source TEXT NOT NULL DEFAULT 'user',
                status TEXT NOT NULL DEFAULT 'active',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT
            );

-- table: household_article_notes (table=household_article_notes)
CREATE TABLE household_article_notes (
                id TEXT PRIMARY KEY,
                household_article_id TEXT NOT NULL,
                note TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );

-- table: household_article_settings (table=household_article_settings)
CREATE TABLE household_article_settings (
                id TEXT PRIMARY KEY,
                household_article_id TEXT NOT NULL,
                setting_key TEXT NOT NULL,
                setting_value TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );

-- table: household_articles (table=household_articles)
CREATE TABLE household_articles (
                id TEXT PRIMARY KEY,
                household_id TEXT NOT NULL,
                naam TEXT NOT NULL,
                consumable INTEGER,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT
            , barcode TEXT, article_number TEXT, external_source TEXT, custom_name TEXT, article_type TEXT, category TEXT, brand_or_maker TEXT, short_description TEXT, notes TEXT, min_stock NUMERIC, ideal_stock NUMERIC, favorite_store TEXT, source TEXT, global_product_id TEXT, article_group_id TEXT, average_price NUMERIC, status TEXT DEFAULT 'active');

-- table: household_memberships (table=household_memberships)
CREATE TABLE household_memberships (
                    id TEXT PRIMARY KEY,
                    household_id TEXT NOT NULL,
                    user_email TEXT NOT NULL,
                    role TEXT NOT NULL DEFAULT 'member',
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(household_id, user_email)
                );

-- table: household_permission_policies (table=household_permission_policies)
CREATE TABLE household_permission_policies (
                id TEXT PRIMARY KEY,
                household_id TEXT NOT NULL,
                permission_key TEXT NOT NULL,
                member_allowed INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(household_id, permission_key)
            );

-- table: household_registry (table=household_registry)
CREATE TABLE household_registry (
                    id TEXT PRIMARY KEY,
                    naam TEXT NOT NULL,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                , context_type TEXT NOT NULL DEFAULT 'regular');

-- table: household_role_change_audit (table=household_role_change_audit)
CREATE TABLE household_role_change_audit (
                id TEXT PRIMARY KEY,
                household_id TEXT NOT NULL,
                changed_user_email TEXT NOT NULL,
                old_role TEXT,
                new_role TEXT,
                changed_by_user_email TEXT NOT NULL,
                action_type TEXT NOT NULL DEFAULT 'role_changed',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );

-- table: household_settings (table=household_settings)
CREATE TABLE household_settings (
                id TEXT PRIMARY KEY,
                household_id TEXT NOT NULL,
                setting_key TEXT NOT NULL,
                setting_value TEXT NOT NULL,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );

-- table: household_store_connections (table=household_store_connections)
CREATE TABLE household_store_connections (
	id VARCHAR NOT NULL, 
	household_id VARCHAR NOT NULL, 
	store_provider_id VARCHAR NOT NULL, 
	connection_status VARCHAR NOT NULL, 
	external_account_ref VARCHAR, 
	consent_scope_json VARCHAR, 
	linked_at DATETIME DEFAULT (CURRENT_TIMESTAMP), 
	last_sync_at DATETIME, 
	created_at DATETIME DEFAULT (CURRENT_TIMESTAMP), 
	updated_at DATETIME DEFAULT (CURRENT_TIMESTAMP), 
	PRIMARY KEY (id), 
	CONSTRAINT uq_household_store_provider UNIQUE (household_id, store_provider_id)
);

-- table: households (table=households)
CREATE TABLE households (
	id VARCHAR NOT NULL, 
	naam VARCHAR NOT NULL, 
	created_at DATETIME DEFAULT (CURRENT_TIMESTAMP), 
	PRIMARY KEY (id)
);

-- table: inventory (table=inventory)
CREATE TABLE inventory (
	id VARCHAR NOT NULL, 
	naam VARCHAR NOT NULL, 
	aantal INTEGER NOT NULL, 
	household_id VARCHAR, 
	space_id VARCHAR, 
	sublocation_id VARCHAR, 
	status VARCHAR NOT NULL, 
	archived_at DATETIME, 
	archive_reason TEXT, 
	created_at DATETIME DEFAULT (CURRENT_TIMESTAMP), 
	updated_at DATETIME, household_article_id TEXT, 
	PRIMARY KEY (id)
);

-- table: inventory_events (table=inventory_events)
CREATE TABLE inventory_events (
                    id TEXT PRIMARY KEY,
                    household_id TEXT NOT NULL,
                    article_id TEXT,
                    household_article_id TEXT,
                    article_name TEXT NOT NULL,
                    location_id TEXT,
                    location_label TEXT,
                    event_type TEXT NOT NULL,
                    quantity NUMERIC NOT NULL,
                    old_quantity NUMERIC,
                    new_quantity NUMERIC,
                    source TEXT NOT NULL,
                    note TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                , purchase_date TEXT, supplier_name TEXT, price NUMERIC, currency TEXT, article_number TEXT, barcode TEXT);

-- table: platform_feature_flags (table=platform_feature_flags)
CREATE TABLE platform_feature_flags (
                flag_key VARCHAR(128) PRIMARY KEY,
                enabled BOOLEAN NOT NULL,
                updated_by VARCHAR(255),
                updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
            );

-- table: product_enrichment_attempts (table=product_enrichment_attempts)
CREATE TABLE product_enrichment_attempts (
                id TEXT PRIMARY KEY,
                global_product_id TEXT,
                household_article_id TEXT,
                source_name TEXT NOT NULL,
                action TEXT NOT NULL,
                status TEXT NOT NULL,
                normalized_barcode TEXT,
                source_request_key TEXT,
                http_status INTEGER,
                response_excerpt TEXT,
                message TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );

-- table: product_enrichment_audit (table=product_enrichment_audit)
CREATE TABLE product_enrichment_audit (
                id TEXT PRIMARY KEY,
                household_article_id TEXT,
                source_name TEXT NOT NULL,
                action TEXT NOT NULL,
                status TEXT NOT NULL,
                message TEXT,
                payload_hash TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                normalized_barcode TEXT,
                source_request_key TEXT,
                http_status INTEGER,
                response_excerpt TEXT
            , global_product_id TEXT);

-- table: product_enrichments (table=product_enrichments)
CREATE TABLE product_enrichments (
                id TEXT PRIMARY KEY,
                household_article_id TEXT NOT NULL,
                source_name TEXT NOT NULL,
                source_record_id TEXT,
                title TEXT,
                brand TEXT,
                category TEXT,
                size_value NUMERIC,
                size_unit TEXT,
                ingredients_json TEXT,
                allergens_json TEXT,
                nutrition_json TEXT,
                image_url TEXT,
                source_url TEXT,
                quality_score NUMERIC,
                fetched_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                expires_at TEXT,
                raw_payload_json TEXT,
                lookup_status TEXT,
                last_lookup_at TEXT,
                last_lookup_source TEXT,
                last_lookup_message TEXT,
                normalized_barcode TEXT
            , global_product_id TEXT, updated_at TEXT);

-- table: product_identities (table=product_identities)
CREATE TABLE product_identities (
                id TEXT PRIMARY KEY,
                household_article_id TEXT NOT NULL,
                identity_type TEXT NOT NULL,
                identity_value TEXT NOT NULL,
                source TEXT NOT NULL,
                confidence_score NUMERIC NOT NULL DEFAULT 1.0,
                is_primary INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT
            , global_product_id TEXT);

-- table: purchase_import_batches (table=purchase_import_batches)
CREATE TABLE purchase_import_batches (
	id VARCHAR NOT NULL, 
	household_id VARCHAR NOT NULL, 
	store_provider_id VARCHAR NOT NULL, 
	connection_id VARCHAR NOT NULL, 
	source_type VARCHAR NOT NULL, 
	source_reference VARCHAR, 
	purchase_date_from DATETIME, 
	purchase_date_to DATETIME, 
	import_status VARCHAR NOT NULL, 
	raw_payload VARCHAR, 
	created_at DATETIME DEFAULT (CURRENT_TIMESTAMP), 
	processed_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(connection_id) REFERENCES household_store_connections (id)
);

-- table: purchase_import_lines (table=purchase_import_lines)
CREATE TABLE purchase_import_lines (
	id VARCHAR NOT NULL, 
	batch_id VARCHAR NOT NULL, 
	external_line_ref VARCHAR, 
	external_article_code VARCHAR, 
	article_name_raw VARCHAR NOT NULL, 
	brand_raw VARCHAR, 
	quantity_raw NUMERIC(10, 2) NOT NULL, 
	unit_raw VARCHAR, 
	line_price_raw NUMERIC(10, 2), 
	currency_code VARCHAR, 
	match_status VARCHAR NOT NULL, 
	matched_global_article_id VARCHAR, 
	target_location_id VARCHAR, 
	created_at DATETIME DEFAULT (CURRENT_TIMESTAMP), 
	updated_at DATETIME DEFAULT (CURRENT_TIMESTAMP), matched_household_article_id TEXT, review_decision TEXT DEFAULT 'pending', reviewed_at DATETIME, reviewed_by TEXT, ui_sort_order INTEGER, matched_global_product_id TEXT, processing_status TEXT DEFAULT 'pending', processed_at DATETIME, processed_event_id TEXT, processing_error TEXT, final_location_id TEXT, suggested_household_article_id TEXT, suggested_location_id TEXT, suggestion_confidence TEXT, suggestion_reason TEXT, is_auto_prefilled INTEGER DEFAULT 0, processing_diagnostics TEXT, article_override_mode TEXT DEFAULT 'auto', location_override_mode TEXT DEFAULT 'auto', selected_article_group_id TEXT, package_count NUMERIC(12,3), content_value NUMERIC(12,3), content_unit TEXT, 
	PRIMARY KEY (id), 
	FOREIGN KEY(batch_id) REFERENCES purchase_import_batches (id)
);

-- table: raw_receipts (table=raw_receipts)
CREATE TABLE raw_receipts (
	id VARCHAR NOT NULL, 
	household_id VARCHAR NOT NULL, 
	source_id VARCHAR, 
	original_filename VARCHAR NOT NULL, 
	mime_type VARCHAR NOT NULL, 
	storage_path TEXT NOT NULL, 
	sha256_hash VARCHAR(64) NOT NULL, 
	imported_at DATETIME DEFAULT (CURRENT_TIMESTAMP), 
	duplicate_of_raw_receipt_id VARCHAR, 
	raw_status VARCHAR NOT NULL, 
	created_at DATETIME DEFAULT (CURRENT_TIMESTAMP), deleted_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(household_id) REFERENCES households (id), 
	FOREIGN KEY(source_id) REFERENCES receipt_sources (id), 
	FOREIGN KEY(duplicate_of_raw_receipt_id) REFERENCES raw_receipts (id)
);

-- table: receipt_email_messages (table=receipt_email_messages)
CREATE TABLE receipt_email_messages (
                    raw_receipt_id TEXT PRIMARY KEY,
                    household_id TEXT NOT NULL,
                    sender_email TEXT,
                    sender_name TEXT,
                    subject TEXT,
                    received_at DATETIME,
                    body_text TEXT,
                    body_html TEXT,
                    selected_part_type TEXT,
                    selected_filename TEXT,
                    selected_mime_type TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
                );

-- table: receipt_gmail_accounts (table=receipt_gmail_accounts)
CREATE TABLE receipt_gmail_accounts (
                    household_id TEXT PRIMARY KEY,
                    source_id TEXT,
                    google_email TEXT,
                    google_user_sub TEXT,
                    label_name TEXT NOT NULL,
                    label_id TEXT,
                    access_token TEXT,
                    refresh_token TEXT,
                    token_expires_at DATETIME,
                    sync_status TEXT NOT NULL DEFAULT 'not_connected',
                    last_synced_at DATETIME,
                    last_error TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
                );

-- table: receipt_gmail_imports (table=receipt_gmail_imports)
CREATE TABLE receipt_gmail_imports (
                    id TEXT PRIMARY KEY,
                    household_id TEXT NOT NULL,
                    gmail_message_id TEXT NOT NULL,
                    gmail_thread_id TEXT,
                    gmail_history_id TEXT,
                    gmail_internal_date DATETIME,
                    raw_receipt_id TEXT,
                    receipt_table_id TEXT,
                    import_status TEXT NOT NULL DEFAULT 'imported',
                    error_message TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
                );

-- table: receipt_import_batches (table=receipt_import_batches)
CREATE TABLE receipt_import_batches (
                id TEXT PRIMARY KEY,
                household_id TEXT NOT NULL,
                source_filename TEXT,
                total_files INTEGER NOT NULL DEFAULT 0,
                processed_files INTEGER NOT NULL DEFAULT 0,
                imported_files INTEGER NOT NULL DEFAULT 0,
                duplicate_files INTEGER NOT NULL DEFAULT 0,
                failed_files INTEGER NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'queued',
                error_message TEXT,
                latest_receipt_table_id TEXT,
                latest_raw_receipt_id TEXT,
                results_json TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                finished_at DATETIME
            );

-- table: receipt_inbound_events (table=receipt_inbound_events)
CREATE TABLE receipt_inbound_events (
                    id TEXT PRIMARY KEY,
                    household_id TEXT,
                    source_id TEXT,
                    provider TEXT NOT NULL,
                    provider_email_id TEXT NOT NULL,
                    provider_message_id TEXT,
                    route_address TEXT,
                    sender_email TEXT,
                    sender_name TEXT,
                    subject TEXT,
                    received_at DATETIME,
                    webhook_received_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    import_status TEXT NOT NULL DEFAULT 'received',
                    raw_receipt_id TEXT,
                    receipt_table_id TEXT,
                    error_message TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
                );

-- table: receipt_processing_runs (table=receipt_processing_runs)
CREATE TABLE receipt_processing_runs (
	id VARCHAR NOT NULL, 
	source_id VARCHAR, 
	started_at DATETIME DEFAULT (CURRENT_TIMESTAMP), 
	finished_at DATETIME, 
	files_found INTEGER NOT NULL, 
	files_imported INTEGER NOT NULL, 
	files_skipped INTEGER NOT NULL, 
	files_failed INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(source_id) REFERENCES receipt_sources (id)
);

-- table: receipt_sources (table=receipt_sources)
CREATE TABLE receipt_sources (
	id VARCHAR NOT NULL, 
	household_id VARCHAR NOT NULL, 
	type VARCHAR NOT NULL, 
	label VARCHAR NOT NULL, 
	source_path TEXT, 
	is_active BOOLEAN NOT NULL, 
	last_scan_at DATETIME, 
	created_at DATETIME DEFAULT (CURRENT_TIMESTAMP), 
	updated_at DATETIME DEFAULT (CURRENT_TIMESTAMP), 
	PRIMARY KEY (id), 
	FOREIGN KEY(household_id) REFERENCES households (id)
);

-- table: receipt_table_lines (table=receipt_table_lines)
CREATE TABLE receipt_table_lines (
	id VARCHAR NOT NULL, 
	receipt_table_id VARCHAR NOT NULL, 
	logical_line_key VARCHAR, 
	line_index INTEGER NOT NULL, 
	raw_label TEXT NOT NULL, 
	normalized_label TEXT, 
	quantity NUMERIC(12, 3), 
	unit VARCHAR, 
	unit_price NUMERIC(12, 4), 
	line_total NUMERIC(12, 2), 
	discount_amount NUMERIC(12, 2), 
	barcode VARCHAR, 
	article_match_status VARCHAR NOT NULL, 
	matched_article_id VARCHAR, 
	confidence_score NUMERIC(5, 4), 
	created_at DATETIME DEFAULT (CURRENT_TIMESTAMP), 
	updated_at DATETIME DEFAULT (CURRENT_TIMESTAMP), line_role TEXT, inventory_eligible INTEGER, package_count NUMERIC(12,3), content_value NUMERIC(12,3), content_unit TEXT, corrected_raw_label TEXT, corrected_quantity NUMERIC(12,3), corrected_unit TEXT, corrected_unit_price NUMERIC(12,4), corrected_line_total NUMERIC(12,2), is_deleted INTEGER NOT NULL DEFAULT 0, is_validated INTEGER NOT NULL DEFAULT 0, matched_global_product_id TEXT, external_article_code TEXT, 
	PRIMARY KEY (id), 
	FOREIGN KEY(receipt_table_id) REFERENCES receipt_tables (id)
);

-- table: receipt_tables (table=receipt_tables)
CREATE TABLE receipt_tables (
	id VARCHAR NOT NULL, 
	raw_receipt_id VARCHAR NOT NULL, 
	household_id VARCHAR NOT NULL, 
	logical_receipt_key VARCHAR, 
	workflow_state VARCHAR NOT NULL, 
	store_name VARCHAR, 
	store_branch VARCHAR, 
	purchase_at DATETIME, 
	total_amount NUMERIC(12, 2), 
	currency VARCHAR(3) NOT NULL, 
	parse_status VARCHAR NOT NULL, 
	confidence_score NUMERIC(5, 4), 
	line_count INTEGER NOT NULL, 
	created_at DATETIME DEFAULT (CURRENT_TIMESTAMP), 
	updated_at DATETIME DEFAULT (CURRENT_TIMESTAMP), deleted_at DATETIME, reference TEXT, notes TEXT, corrected_by_user_email TEXT, approved_by_user_email TEXT, approved_at DATETIME, reviewed_at DATETIME, totals_overridden INTEGER NOT NULL DEFAULT 0, totals_override_by_user_email TEXT, totals_override_at DATETIME, store_name_source TEXT NOT NULL DEFAULT 'detected', purchase_at_source TEXT NOT NULL DEFAULT 'detected', discount_total NUMERIC(12,2), 
	PRIMARY KEY (id), 
	UNIQUE (raw_receipt_id), 
	FOREIGN KEY(raw_receipt_id) REFERENCES raw_receipts (id), 
	FOREIGN KEY(household_id) REFERENCES households (id)
);

-- table: spaces (table=spaces)
CREATE TABLE spaces (
	id VARCHAR NOT NULL, 
	naam VARCHAR NOT NULL, 
	household_id VARCHAR, active INTEGER NOT NULL DEFAULT 1, 
	PRIMARY KEY (id)
);

-- table: store_import_memory (table=store_import_memory)
CREATE TABLE store_import_memory (
                    id TEXT PRIMARY KEY,
                    household_id TEXT NOT NULL,
                    store_provider_code TEXT NOT NULL,
                    raw_article_name TEXT NOT NULL,
                    raw_brand TEXT,
                    normalized_key TEXT NOT NULL,
                    matched_household_article_id TEXT NOT NULL,
                    preferred_location_id TEXT,
                    times_confirmed INTEGER NOT NULL DEFAULT 1,
                    last_used_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
                );

-- table: store_providers (table=store_providers)
CREATE TABLE store_providers (
	id VARCHAR NOT NULL, 
	code VARCHAR NOT NULL, 
	name VARCHAR NOT NULL, 
	status VARCHAR NOT NULL, 
	import_mode VARCHAR NOT NULL, 
	created_at DATETIME DEFAULT (CURRENT_TIMESTAMP), 
	updated_at DATETIME DEFAULT (CURRENT_TIMESTAMP), 
	PRIMARY KEY (id), 
	UNIQUE (code)
);

-- table: sublocations (table=sublocations)
CREATE TABLE sublocations (
	id VARCHAR NOT NULL, 
	naam VARCHAR NOT NULL, 
	space_id VARCHAR, active INTEGER NOT NULL DEFAULT 1, 
	PRIMARY KEY (id)
);

-- table: user_settings (table=user_settings)
CREATE TABLE user_settings (
                id TEXT PRIMARY KEY,
                user_email TEXT NOT NULL,
                setting_key TEXT NOT NULL,
                setting_value TEXT NOT NULL,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );

-- index: idx_actor_object_attributions_household_actor (table=actor_object_attributions)
CREATE INDEX idx_actor_object_attributions_household_actor
        ON actor_object_attributions (household_id, actor_user_id, object_type);

-- index: idx_article_groups_household_name (table=article_groups)
CREATE INDEX idx_article_groups_household_name
ON article_groups (household_id, normalized_name);

-- index: idx_auth_single_active_ip_owner (table=auth_platform_user_roles)
CREATE UNIQUE INDEX idx_auth_single_active_ip_owner
        ON auth_platform_user_roles(role_key)
        WHERE role_key = 'platform.ip_owner' AND active = 1;

-- index: idx_external_article_product_links_candidate (table=external_article_product_links)
CREATE INDEX idx_external_article_product_links_candidate
            ON external_article_product_links (
                source_candidate_id
            );

-- index: idx_external_article_product_links_product (table=external_article_product_links)
CREATE INDEX idx_external_article_product_links_product
            ON external_article_product_links (
                global_product_id,
                status
            );

-- index: idx_external_product_candidates_global_product (table=external_product_candidates)
CREATE INDEX idx_external_product_candidates_global_product
            ON external_product_candidates (global_product_id);

-- index: idx_external_product_candidates_line (table=external_product_candidates)
CREATE INDEX idx_external_product_candidates_line
            ON external_product_candidates (purchase_import_line_id, status, score);

-- index: idx_external_product_candidates_source_code (table=external_product_candidates)
CREATE INDEX idx_external_product_candidates_source_code
            ON external_product_candidates (source_name, source_product_code);

-- index: idx_global_products_primary_gtin (table=global_products)
CREATE UNIQUE INDEX idx_global_products_primary_gtin ON global_products (primary_gtin) WHERE primary_gtin IS NOT NULL AND trim(primary_gtin) <> '';

-- index: idx_household_article_notes_unique (table=household_article_notes)
CREATE UNIQUE INDEX idx_household_article_notes_unique ON household_article_notes (household_article_id);

-- index: idx_household_article_settings_unique (table=household_article_settings)
CREATE UNIQUE INDEX idx_household_article_settings_unique ON household_article_settings (household_article_id, setting_key);

-- index: idx_household_articles_article_group (table=household_articles)
CREATE INDEX idx_household_articles_article_group
ON household_articles (article_group_id);

-- index: idx_household_articles_global_product (table=household_articles)
CREATE INDEX idx_household_articles_global_product ON household_articles (global_product_id);

-- index: idx_household_articles_household_article_number (table=household_articles)
CREATE INDEX idx_household_articles_household_article_number ON household_articles (household_id, article_number);

-- index: idx_household_articles_household_barcode (table=household_articles)
CREATE INDEX idx_household_articles_household_barcode ON household_articles (household_id, barcode);

-- index: idx_household_articles_household_global_product (table=household_articles)
CREATE UNIQUE INDEX idx_household_articles_household_global_product ON household_articles (household_id, global_product_id) WHERE global_product_id IS NOT NULL AND trim(global_product_id) <> '';

-- index: idx_household_articles_household_global_product_lookup (table=household_articles)
CREATE INDEX idx_household_articles_household_global_product_lookup ON household_articles (household_id, global_product_id);

-- index: idx_household_articles_household_name (table=household_articles)
CREATE INDEX idx_household_articles_household_name ON household_articles (household_id, naam);

-- index: idx_household_memberships_email (table=household_memberships)
CREATE INDEX idx_household_memberships_email ON household_memberships (user_email);

-- index: idx_household_memberships_household (table=household_memberships)
CREATE INDEX idx_household_memberships_household ON household_memberships (household_id);

-- index: idx_household_permission_policies_unique (table=household_permission_policies)
CREATE UNIQUE INDEX idx_household_permission_policies_unique ON household_permission_policies (household_id, permission_key);

-- index: idx_household_role_change_audit_household_created (table=household_role_change_audit)
CREATE INDEX idx_household_role_change_audit_household_created ON household_role_change_audit (household_id, created_at DESC);

-- index: idx_household_settings_unique (table=household_settings)
CREATE UNIQUE INDEX idx_household_settings_unique ON household_settings (household_id, setting_key);

-- index: idx_inventory_events_household_article_id (table=inventory_events)
CREATE INDEX idx_inventory_events_household_article_id ON inventory_events (household_article_id);

-- index: idx_inventory_household_article_id (table=inventory)
CREATE INDEX idx_inventory_household_article_id ON inventory (household_article_id);

-- index: idx_product_enrichment_attempts_article (table=product_enrichment_attempts)
CREATE INDEX idx_product_enrichment_attempts_article ON product_enrichment_attempts (household_article_id, created_at);

-- index: idx_product_enrichment_attempts_article_lookup (table=product_enrichment_attempts)
CREATE INDEX idx_product_enrichment_attempts_article_lookup ON product_enrichment_attempts (household_article_id, global_product_id, created_at);

-- index: idx_product_enrichment_attempts_global_product (table=product_enrichment_attempts)
CREATE INDEX idx_product_enrichment_attempts_global_product ON product_enrichment_attempts (global_product_id, created_at);

-- index: idx_product_enrichment_attempts_global_product_latest (table=product_enrichment_attempts)
CREATE INDEX idx_product_enrichment_attempts_global_product_latest ON product_enrichment_attempts (global_product_id, created_at);

-- index: idx_product_enrichment_audit_article (table=product_enrichment_audit)
CREATE INDEX idx_product_enrichment_audit_article ON product_enrichment_audit (household_article_id, created_at);

-- index: idx_product_enrichment_audit_global_product (table=product_enrichment_audit)
CREATE INDEX idx_product_enrichment_audit_global_product ON product_enrichment_audit (global_product_id, created_at);

-- index: idx_product_enrichment_audit_global_product_latest (table=product_enrichment_audit)
CREATE INDEX idx_product_enrichment_audit_global_product_latest ON product_enrichment_audit (global_product_id, created_at);

-- index: idx_product_enrichments_article (table=product_enrichments)
CREATE INDEX idx_product_enrichments_article ON product_enrichments (household_article_id);

-- index: idx_product_enrichments_global_product (table=product_enrichments)
CREATE INDEX idx_product_enrichments_global_product ON product_enrichments (global_product_id, source_name);

-- index: idx_product_enrichments_global_product_latest (table=product_enrichments)
CREATE INDEX idx_product_enrichments_global_product_latest ON product_enrichments (global_product_id, source_name, last_lookup_at, fetched_at);

-- index: idx_product_enrichments_global_product_lookup (table=product_enrichments)
CREATE INDEX idx_product_enrichments_global_product_lookup ON product_enrichments (global_product_id, source_name, fetched_at);

-- index: idx_product_enrichments_global_product_source_unique (table=product_enrichments)
CREATE UNIQUE INDEX idx_product_enrichments_global_product_source_unique ON product_enrichments (global_product_id, source_name) WHERE global_product_id IS NOT NULL AND trim(global_product_id) <> '';

-- index: idx_product_enrichments_lookup_status (table=product_enrichments)
CREATE INDEX idx_product_enrichments_lookup_status ON product_enrichments (lookup_status);

-- index: idx_product_enrichments_unique_source (table=product_enrichments)
CREATE UNIQUE INDEX idx_product_enrichments_unique_source ON product_enrichments (household_article_id, source_name);

-- index: idx_product_identities_article (table=product_identities)
CREATE INDEX idx_product_identities_article ON product_identities (household_article_id, is_primary);

-- index: idx_product_identities_global_product (table=product_identities)
CREATE INDEX idx_product_identities_global_product ON product_identities (global_product_id, is_primary);

-- index: idx_product_identities_global_product_identity (table=product_identities)
CREATE INDEX idx_product_identities_global_product_identity ON product_identities (global_product_id, identity_type, identity_value);

-- index: idx_product_identities_unique_value (table=product_identities)
CREATE UNIQUE INDEX idx_product_identities_unique_value ON product_identities (identity_type, identity_value);

-- index: idx_raw_receipts_household_deleted (table=raw_receipts)
CREATE INDEX idx_raw_receipts_household_deleted ON raw_receipts (household_id, deleted_at);

-- index: idx_raw_receipts_source_imported (table=raw_receipts)
CREATE INDEX idx_raw_receipts_source_imported ON raw_receipts (source_id, imported_at DESC);

-- index: idx_receipt_email_messages_household_received (table=receipt_email_messages)
CREATE INDEX idx_receipt_email_messages_household_received ON receipt_email_messages (household_id, received_at DESC);

-- index: idx_receipt_gmail_accounts_sync (table=receipt_gmail_accounts)
CREATE INDEX idx_receipt_gmail_accounts_sync ON receipt_gmail_accounts (sync_status, last_synced_at DESC);

-- index: idx_receipt_gmail_imports_household_created (table=receipt_gmail_imports)
CREATE INDEX idx_receipt_gmail_imports_household_created ON receipt_gmail_imports (household_id, created_at DESC);

-- index: idx_receipt_inbound_household_received (table=receipt_inbound_events)
CREATE INDEX idx_receipt_inbound_household_received ON receipt_inbound_events (household_id, received_at DESC, created_at DESC);

-- index: idx_receipt_lines_receipt_active (table=receipt_table_lines)
CREATE INDEX idx_receipt_lines_receipt_active ON receipt_table_lines (receipt_table_id, is_deleted, line_index);

-- index: idx_receipt_lines_receipt_lineindex (table=receipt_table_lines)
CREATE INDEX idx_receipt_lines_receipt_lineindex ON receipt_table_lines (receipt_table_id, line_index);

-- index: idx_receipt_sources_household_active (table=receipt_sources)
CREATE INDEX idx_receipt_sources_household_active ON receipt_sources (household_id, is_active);

-- index: idx_receipt_table_lines_logical_line_key (table=receipt_table_lines)
CREATE INDEX idx_receipt_table_lines_logical_line_key ON receipt_table_lines (logical_line_key);

-- index: idx_receipt_tables_household_created (table=receipt_tables)
CREATE INDEX idx_receipt_tables_household_created ON receipt_tables (household_id, created_at DESC);

-- index: idx_receipt_tables_household_deleted (table=receipt_tables)
CREATE INDEX idx_receipt_tables_household_deleted ON receipt_tables (household_id, deleted_at);

-- index: idx_receipt_tables_logical_receipt_key (table=receipt_tables)
CREATE INDEX idx_receipt_tables_logical_receipt_key ON receipt_tables (household_id, logical_receipt_key);

-- index: idx_receipt_tables_status_created (table=receipt_tables)
CREATE INDEX idx_receipt_tables_status_created ON receipt_tables (parse_status, created_at DESC);

-- index: idx_receipt_tables_workflow_state (table=receipt_tables)
CREATE INDEX idx_receipt_tables_workflow_state ON receipt_tables (household_id, workflow_state);

-- index: idx_store_import_memory_unique (table=store_import_memory)
CREATE UNIQUE INDEX idx_store_import_memory_unique ON store_import_memory (household_id, store_provider_code, normalized_key);

-- index: idx_user_settings_unique (table=user_settings)
CREATE UNIQUE INDEX idx_user_settings_unique ON user_settings (user_email, setting_key);

-- index: uq_external_article_product_links_code_confirmed (table=external_article_product_links)
CREATE UNIQUE INDEX uq_external_article_product_links_code_confirmed
            ON external_article_product_links (
                retailer_code,
                external_article_code
            )
            WHERE
                status = 'confirmed'
                AND external_article_code <> '';

-- index: uq_external_article_product_links_text_confirmed (table=external_article_product_links)
CREATE UNIQUE INDEX uq_external_article_product_links_text_confirmed
            ON external_article_product_links (
                retailer_code,
                receipt_text_normalized
            )
            WHERE
                status = 'confirmed'
                AND receipt_text_normalized <> '';

-- index: uq_global_products_active_fingerprint (table=global_products)
CREATE UNIQUE INDEX uq_global_products_active_fingerprint
            ON global_products (product_fingerprint)
            WHERE status = 'active'
              AND COALESCE(trim(primary_gtin), '') = ''
              AND COALESCE(trim(product_fingerprint), '') <> '';

-- index: uq_raw_receipts_household_hash (table=raw_receipts)
CREATE UNIQUE INDEX uq_raw_receipts_household_hash ON raw_receipts (household_id, sha256_hash) WHERE deleted_at IS NULL;

-- index: uq_receipt_gmail_imports_household_message (table=receipt_gmail_imports)
CREATE UNIQUE INDEX uq_receipt_gmail_imports_household_message ON receipt_gmail_imports (household_id, gmail_message_id);

-- index: uq_receipt_inbound_provider_email (table=receipt_inbound_events)
CREATE UNIQUE INDEX uq_receipt_inbound_provider_email ON receipt_inbound_events (provider, provider_email_id);

-- index: uq_receipt_table_lines_receipt_line (table=receipt_table_lines)
CREATE UNIQUE INDEX uq_receipt_table_lines_receipt_line ON receipt_table_lines (receipt_table_id, line_index);

-- trigger: trg_app_users_account_status_insert (table=app_users)
CREATE TRIGGER trg_app_users_account_status_insert
                BEFORE INSERT ON app_users
                WHEN NEW.account_status NOT IN ('active', 'disabled')
                BEGIN
                    SELECT RAISE(ABORT, 'invalid account_status');
                END;

-- trigger: trg_app_users_account_status_update (table=app_users)
CREATE TRIGGER trg_app_users_account_status_update
                BEFORE UPDATE OF account_status ON app_users
                WHEN NEW.account_status NOT IN ('active', 'disabled')
                BEGIN
                    SELECT RAISE(ABORT, 'invalid account_status');
                END;

-- trigger: trg_household_context_type_insert (table=household_registry)
CREATE TRIGGER trg_household_context_type_insert
                BEFORE INSERT ON household_registry
                WHEN NEW.context_type NOT IN ('regular', 'system')
                BEGIN
                    SELECT RAISE(ABORT, 'invalid household context_type');
                END;

-- trigger: trg_household_context_type_update (table=household_registry)
CREATE TRIGGER trg_household_context_type_update
                BEFORE UPDATE OF context_type ON household_registry
                WHEN NEW.context_type NOT IN ('regular', 'system')
                BEGIN
                    SELECT RAISE(ABORT, 'invalid household context_type');
                END;

-- trigger: trg_household_zero_system_insert (table=household_registry)
CREATE TRIGGER trg_household_zero_system_insert
                AFTER INSERT ON household_registry
                WHEN CAST(NEW.id AS TEXT) = '0' AND NEW.context_type <> 'system'
                BEGIN
                    UPDATE household_registry
                    SET context_type = 'system'
                    WHERE id = NEW.id;
                END;

-- trigger: trg_receipt_tables_preserve_explicit_approval (table=receipt_tables)
CREATE TRIGGER trg_receipt_tables_preserve_explicit_approval
            AFTER UPDATE OF parse_status, approved_at ON receipt_tables
            WHEN NEW.approved_at IS NOT NULL
             AND NEW.deleted_at IS NULL
             AND (
                    lower(trim(COALESCE(NEW.parse_status, ''))) NOT IN (
                        'approved', 'approved_override'
                    )
                    OR lower(trim(COALESCE(NEW.workflow_state, 'active'))) = 'returned_to_kassa'
             )
             AND lower(trim(COALESCE(NEW.workflow_state, 'active'))) NOT IN (
                    'archived', 'removed_reimport_allowed', 'legacy_deleted'
             )
             AND EXISTS (
                    SELECT 1
                    FROM raw_receipts rr
                    WHERE rr.id = NEW.raw_receipt_id
                      AND rr.deleted_at IS NULL
             )
            BEGIN
                UPDATE receipt_tables
                SET parse_status = CASE WHEN COALESCE(NEW.totals_overridden, 0) <> 0 THEN 'approved_override' ELSE 'approved' END,
                    workflow_state = CASE
                        WHEN lower(trim(COALESCE(NEW.workflow_state, 'active'))) = 'returned_to_kassa'
                        THEN 'active'
                        ELSE NEW.workflow_state
                    END,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = NEW.id;
            END;
